# ViralTrend AI

Structure de base du projet.